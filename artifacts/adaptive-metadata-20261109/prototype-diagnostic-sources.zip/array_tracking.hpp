#ifndef MGMEM_FUSION_ARRAY_TRACKING_HPP
#define MGMEM_FUSION_ARRAY_TRACKING_HPP

#include "counting_allocator.hpp"
#include <array>
#include <cstdlib>
#include <mutex>

namespace heap_probe {
struct ArrayEntry { void *address = nullptr; std::size_t bytes = 0; int kind = -1; };
struct KindArrays { uint64_t allocated = 0, deallocated = 0, live = 0, peak = 0; };
inline std::array<ArrayEntry, 64> array_registry{};
inline std::array<KindArrays, 2> kind_arrays{};
inline std::mutex array_mutex;
inline thread_local int marked_array_kind = -1;
inline uint64_t unmarked_allocations = 0, unmarked_deallocations = 0;
inline uint64_t peak_registered_arrays = 0, peak_marked_arrays = 0;
inline uint64_t live_marked_bytes = 0, peak_marked_bytes = 0, registry_errors = 0;

inline bool table_kind(int kind) noexcept {
    return kind == MGMEM_HP_ALLOCATION_TABLE_STORAGE || kind == MGMEM_HP_LEASE_TABLE_STORAGE;
}
struct TableArrayScope {
    int previous;
    explicit TableArrayScope(unsigned kind) noexcept : previous(marked_array_kind) {
        marked_array_kind = static_cast<int>(kind);
    }
    ~TableArrayScope() { marked_array_kind = previous; }
    TableArrayScope(const TableArrayScope &) = delete;
    TableArrayScope &operator=(const TableArrayScope &) = delete;
};

inline void *allocate_array(std::size_t bytes) {
    const int kind = marked_array_kind;
    const bool marked = table_kind(kind);
    if (marked) counters[static_cast<unsigned>(kind)].attempts.fetch_add(1, std::memory_order_relaxed);
    void *address;
    try { address = ::operator new(bytes); }
    catch (...) {
        if (marked) counters[static_cast<unsigned>(kind)].failed.fetch_add(1, std::memory_order_relaxed);
        throw;
    }
    std::lock_guard<std::mutex> lock(array_mutex);
    ArrayEntry *empty = nullptr;
    uint64_t live = 0, table_live = 0;
    for (auto &entry : array_registry) {
        if (entry.address) { ++live; if (table_kind(entry.kind)) ++table_live; }
        else if (!empty) empty = &entry;
    }
    if (!empty) {
        ++registry_errors;
        ::operator delete(address);
        if (marked) counters[static_cast<unsigned>(kind)].failed.fetch_add(1, std::memory_order_relaxed);
        throw std::bad_alloc();
    }
    *empty = {address, bytes, marked ? kind : -1};
    if (live + 1 > peak_registered_arrays) peak_registered_arrays = live + 1;
    if (marked) {
        auto &stats = kind_arrays[static_cast<unsigned>(kind) - 1];
        ++stats.allocated;
        if (++stats.live > stats.peak) stats.peak = stats.live;
        if (table_live + 1 > peak_marked_arrays) peak_marked_arrays = table_live + 1;
        live_marked_bytes += static_cast<uint64_t>(bytes);
        if (live_marked_bytes > peak_marked_bytes) peak_marked_bytes = live_marked_bytes;
        record_allocation(static_cast<unsigned>(kind), static_cast<uint64_t>(bytes));
    } else ++unmarked_allocations;
    return address;
}

inline void deallocate_array(void *address) noexcept {
    if (!address) return;
    std::lock_guard<std::mutex> lock(array_mutex);
    for (auto &entry : array_registry) if (entry.address == address) {
        // The matching allocator above delegates to scalar global new without
        // adding a prefix. Return its exact address to scalar global delete.
        ::operator delete(address);
        if (table_kind(entry.kind)) {
            auto &stats = kind_arrays[static_cast<unsigned>(entry.kind) - 1];
            ++stats.deallocated;
            --stats.live;
            live_marked_bytes -= static_cast<uint64_t>(entry.bytes);
            record_deallocation(static_cast<unsigned>(entry.kind), static_cast<uint64_t>(entry.bytes));
        } else ++unmarked_deallocations;
        entry = {};
        return;
    }
    ++registry_errors;
    std::abort();
}

inline bool array_snapshot(mgmem_heap_probe_array_v2 &out) noexcept {
    std::lock_guard<std::mutex> lock(array_mutex);
    uint64_t unmarked = 0;
    for (const auto &entry : array_registry)
        if (entry.address && !table_kind(entry.kind)) ++unmarked;
    for (unsigned i = 0; i < 2; ++i) {
        const auto &v = kind_arrays[i];
        out.kinds[i] = {v.allocated, v.deallocated, v.live, v.peak};
    }
    out.unmarked_allocations = unmarked_allocations;
    out.unmarked_deallocations = unmarked_deallocations;
    out.live_unmarked_arrays = unmarked;
    out.peak_registered_arrays = peak_registered_arrays;
    out.peak_live_marked_arrays = peak_marked_arrays;
    out.live_marked_request_bytes = live_marked_bytes;
    out.peak_live_marked_request_bytes = peak_marked_bytes;
    out.registry_capacity = array_registry.size();
    out.registry_errors = registry_errors;
    return registry_errors == 0;
}
} // namespace heap_probe

void *operator new[](std::size_t bytes) { return heap_probe::allocate_array(bytes); }
void operator delete[](void *address) noexcept { heap_probe::deallocate_array(address); }
void operator delete[](void *address, std::size_t) noexcept { heap_probe::deallocate_array(address); }

#endif
