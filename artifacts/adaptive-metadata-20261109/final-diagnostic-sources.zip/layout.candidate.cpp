#define PROBE_LAYOUT_STORAGE "ADAPTIVE_SBO1_ARRAYS_INTRUSIVE_BACKING"
#define PROBE_LAYOUT_COUNTED 0
#include "core.candidate.cpp"

#include <cstdio>
#include <utility>
int main() {
    using Owners = decltype(std::declval<mgmem_domain>().allocations);
    using Leases = decltype(std::declval<mgmem_domain>().leases);
    std::printf("{\"scope\":\"HOST_RELEASE_CONTROL_LAYOUT_ONLY_NOT_RSS\",\"instrumented\":%s,\"storage\":\"%s\",\"domain\":%llu,\"owner_storage_object\":%llu,\"lease_storage_object\":%llu,\"Allocation\":%llu,\"Lease\":%llu,\"Backing\":%llu,\"pointer\":%llu,\"owner_element\":%llu,\"lease_element\":%llu}\n",
        PROBE_LAYOUT_COUNTED ? "true" : "false", PROBE_LAYOUT_STORAGE,
        (unsigned long long)sizeof(mgmem_domain), (unsigned long long)sizeof(Owners), (unsigned long long)sizeof(Leases),
        (unsigned long long)sizeof(Allocation), (unsigned long long)sizeof(Lease), (unsigned long long)sizeof(Backing),
        (unsigned long long)sizeof(void *), (unsigned long long)sizeof(*std::declval<Owners &>().find(1)),
        (unsigned long long)sizeof(*std::declval<Leases &>().find(1)));
}
