#ifndef MGMEM_HEAP_PROBE_COUNTING_ALLOCATOR_HPP
#define MGMEM_HEAP_PROBE_COUNTING_ALLOCATOR_HPP

#include "probe_api.h"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <new>
#include <type_traits>

namespace heap_probe {
struct AtomicCounter {
    std::atomic<uint64_t> attempts{0}, allocated{0}, failed{0}, deallocated{0};
    std::atomic<uint64_t> allocated_bytes{0}, deallocated_bytes{0}, live_bytes{0}, peak_bytes{0};
    std::atomic<uint64_t> minimum{std::numeric_limits<uint64_t>::max()}, maximum{0};
};
inline std::array<AtomicCounter, MGMEM_HP_KIND_COUNT> counters{};

inline void record_allocation(unsigned kind, uint64_t bytes) noexcept {
    auto &c = counters[kind];
    c.allocated.fetch_add(1, std::memory_order_relaxed);
    c.allocated_bytes.fetch_add(bytes, std::memory_order_relaxed);
    const auto live = c.live_bytes.fetch_add(bytes, std::memory_order_relaxed) + bytes;
    auto peak = c.peak_bytes.load(std::memory_order_relaxed);
    while (peak < live && !c.peak_bytes.compare_exchange_weak(peak, live, std::memory_order_relaxed)) {}
    auto minimum = c.minimum.load(std::memory_order_relaxed);
    while (minimum > bytes && !c.minimum.compare_exchange_weak(minimum, bytes, std::memory_order_relaxed)) {}
    auto maximum = c.maximum.load(std::memory_order_relaxed);
    while (maximum < bytes && !c.maximum.compare_exchange_weak(maximum, bytes, std::memory_order_relaxed)) {}
}

inline void record_deallocation(unsigned kind, uint64_t bytes) noexcept {
    auto &c = counters[kind];
    c.deallocated.fetch_add(1, std::memory_order_relaxed);
    c.deallocated_bytes.fetch_add(bytes, std::memory_order_relaxed);
    c.live_bytes.fetch_sub(bytes, std::memory_order_relaxed);
}

inline void *allocate_domain(std::size_t bytes) {
    auto &c = counters[MGMEM_HP_DOMAIN];
    c.attempts.fetch_add(1, std::memory_order_relaxed);
    void *result;
    try { result = ::operator new(bytes); }
    catch (...) { c.failed.fetch_add(1, std::memory_order_relaxed); throw; }
    record_allocation(MGMEM_HP_DOMAIN, static_cast<uint64_t>(bytes));
    return result;
}

inline void deallocate_domain(void *address, std::size_t bytes) noexcept {
    if (!address) return;
    ::operator delete(address);
    record_deallocation(MGMEM_HP_DOMAIN, static_cast<uint64_t>(bytes));
}

template<class T, unsigned Kind>
struct CountingAllocator {
    using value_type = T;
    using propagate_on_container_move_assignment = std::true_type;
    using is_always_equal = std::true_type;
    template<class U> struct rebind { using other = CountingAllocator<U, Kind>; };

    CountingAllocator() noexcept = default;
    template<class U> CountingAllocator(const CountingAllocator<U, Kind> &) noexcept {}

    T *allocate(std::size_t count) {
        auto &c = counters[Kind];
        c.attempts.fetch_add(1, std::memory_order_relaxed);
        T *result;
        try { result = std::allocator<T>{}.allocate(count); }
        catch (...) { c.failed.fetch_add(1, std::memory_order_relaxed); throw; }
        // Record the actual successful upstream request after allocator rebind.
        // This includes implementation node/head/proxy bytes, not sizeof(value_type).
        record_allocation(Kind, static_cast<uint64_t>(count * sizeof(T)));
        return result;
    }
    void deallocate(T *address, std::size_t count) noexcept {
        std::allocator<T>{}.deallocate(address, count);
        record_deallocation(Kind, static_cast<uint64_t>(count * sizeof(T)));
    }
};

template<class T, class U, unsigned Kind>
bool operator==(const CountingAllocator<T, Kind> &, const CountingAllocator<U, Kind> &) noexcept { return true; }
template<class T, class U, unsigned Kind>
bool operator!=(const CountingAllocator<T, Kind> &, const CountingAllocator<U, Kind> &) noexcept { return false; }

inline void snapshot(mgmem_heap_probe_counter_v1 *out) noexcept {
    for (unsigned i = 0; i < MGMEM_HP_KIND_COUNT; ++i) {
        const auto &c = counters[i];
        const auto allocated = c.allocated.load(std::memory_order_relaxed);
        out[i] = {c.attempts.load(std::memory_order_relaxed), allocated,
            c.failed.load(std::memory_order_relaxed), c.deallocated.load(std::memory_order_relaxed),
            c.allocated_bytes.load(std::memory_order_relaxed), c.deallocated_bytes.load(std::memory_order_relaxed),
            c.live_bytes.load(std::memory_order_relaxed), c.peak_bytes.load(std::memory_order_relaxed),
            allocated ? c.minimum.load(std::memory_order_relaxed) : 0,
            c.maximum.load(std::memory_order_relaxed)};
    }
}
// Intrusive candidate: the allocator observes the actual scalar operator-new
// request, not an emplace event. Backing object layout receives no extra field.
template<class T>
T *allocate_backing_record(const T &value) {
    static_assert(alignof(T) <= alignof(std::max_align_t), "regular record alignment");
    CountingAllocator<T, MGMEM_HP_BACKING_LIST> allocator;
    T *node = allocator.allocate(1);
    try { return ::new (static_cast<void *>(node)) T(value); }
    catch (...) { allocator.deallocate(node, 1); throw; }
}
template<class T>
void deallocate_backing_record(T *node) noexcept {
    if (!node) return;
    node->~T();
    CountingAllocator<T, MGMEM_HP_BACKING_LIST>{}.deallocate(node, 1);
}

} // namespace heap_probe
#endif
