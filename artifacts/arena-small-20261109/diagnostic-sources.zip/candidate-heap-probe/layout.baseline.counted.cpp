#include "core.baseline.counted.cpp"

#include "counting_allocator.hpp"
#include <cstdio>
#include <type_traits>
#include <utility>

int main() {
    using ActualLeaseMap = decltype(std::declval<mgmem_domain>().leases);
    using ActualNodeHandle = typename ActualLeaseMap::node_type;
    using ObservedMap = std::map<u64, Lease, std::less<u64>,
        heap_probe::CountingAllocator<std::pair<const u64, Lease>, MGMEM_HP_LEASE_MAP>>;
    mgmem_heap_probe_counter_v1 before[MGMEM_HP_KIND_COUNT]{};
    mgmem_heap_probe_counter_v1 after[MGMEM_HP_KIND_COUNT]{};
    ObservedMap observed;
    heap_probe::snapshot(before); // Exclude the map's head/sentinel construction.
    observed.emplace(1, Lease{0, false});
    heap_probe::snapshot(after);
    auto node = observed.extract(observed.begin());
    const auto calls = after[MGMEM_HP_LEASE_MAP].successful_allocations - before[MGMEM_HP_LEASE_MAP].successful_allocations;
    const auto bytes = after[MGMEM_HP_LEASE_MAP].allocated_request_bytes - before[MGMEM_HP_LEASE_MAP].allocated_request_bytes;
    node = decltype(node){};
    std::printf("{\"scope\":\"HOST_RELEASE_LAYOUT_AND_DIAGNOSTIC_UPSTREAM_REQUEST_ONLY\","
        "\"domain\":%llu,\"allocation_map\":%llu,\"lease_map\":%llu,"
        "\"lease_node_handle\":%llu,\"counted_lease_node_handle\":%llu,"
        "\"Backing\":%llu,\"Allocation\":%llu,\"Lease\":%llu,\"pointer\":%llu,"
        "\"node_probe_upstream_allocations\":%llu,\"node_probe_request_bytes\":%llu,"
        "\"is_rss_or_allocator_usable_size\":false}\n",
        static_cast<unsigned long long>(sizeof(mgmem_domain)),
        static_cast<unsigned long long>(sizeof(decltype(std::declval<mgmem_domain>().allocations))),
        static_cast<unsigned long long>(sizeof(ActualLeaseMap)),
        static_cast<unsigned long long>(sizeof(ActualNodeHandle)),
        static_cast<unsigned long long>(sizeof(typename ObservedMap::node_type)),
        static_cast<unsigned long long>(sizeof(Backing)), static_cast<unsigned long long>(sizeof(Allocation)),
        static_cast<unsigned long long>(sizeof(Lease)), static_cast<unsigned long long>(sizeof(void *)),
        static_cast<unsigned long long>(calls), static_cast<unsigned long long>(bytes));
    return calls == 1 && bytes != 0 ? 0 : 1;
}
