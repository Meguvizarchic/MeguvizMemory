"""Frozen, scoped C++17 convenience comparisons; no retries or exclusions."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE.parent
CORE = '8628ce7f460e371a353e7a2121cfb673cd8f1b75a325e28961055d9bf8242586'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save(path, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    assert not path.exists() or path.read_bytes() == data, 'output_already_exists:' + path.name
    path.write_bytes(data)

def groups():
    rows = []
    for domain in ['system', 'arena']:
        for workload, cycles in [('cold', 1), ('scoped', 256)]:
            rows.append({'id': domain + '-' + workload, 'domain': domain, 'case': workload,
                         'range': 'whole', 'cycles': cycles, 'rounds': 12, 'warmup': 4})
        for workload in ['read', 'write']:
            for span in ['whole', 'sub']:
                rows.append({'id': domain + '-' + workload + '-' + span, 'domain': domain,
                    'case': workload, 'range': span, 'cycles': 1024, 'rounds': 12, 'warmup': 4})
    assert len(rows) == 12
    return rows

def frozen(plan):
    for name, item in plan['files'].items():
        p = Path(name)
        assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'changed_input:' + p.name

def percentile(values, p):
    return sorted(values)[int((len(values) - 1) * p + .5)]

def oracle(spec):
    n = spec['cycles']
    if spec['case'] in ('cold', 'scoped'):
        return sum((i * 17 + b * 3 + 11) & 255 for i in range(n) for b in range(64)), n * 64
    off, length = (32, 64) if spec['range'] == 'sub' else (0, 128)
    if spec['case'] == 'read':
        return n * sum(((b + off) * 3 + 11) & 255 for b in range(length)), n * length
    return sum((i * 17 + (b + off) * 3 + 11) & 255 for i in range(n) for b in range(length)), n * length

def expected_native(spec, hot):
    n = spec['cycles']
    expected = {key: 0 for key in ['create', 'allocate', 'acquire', 'release_lease',
        'release_owner', 'reset', 'begin_close', 'collect', 'drain', 'destroy', 'snapshot']}
    scoped = spec['case'] in ('cold', 'scoped')
    expected.update(acquire=n, release_lease=n)
    if scoped:
        expected.update(allocate=n, release_owner=n,
            reset=n if spec['domain'] == 'arena' and spec['case'] != 'cold' else 0)
    if not hot:
        expected.update(create=1, begin_close=1, collect=1, drain=1, destroy=1, snapshot=1)
        if not scoped:
            expected.update(allocate=1, release_owner=1, acquire=n + 1, release_lease=n + 1)
    return expected

def validate(data, spec, method, count_only, plan):
    assert data['success'] is True and data['performance_qualified'] is False
    assert data['schema_version'] == 1 and data['final_resources'] == 'CLOSED_ZERO'
    assert data['count_only'] == count_only and data['method'] == method
    assert data['config_source'] == ('NATIVE_CREATE_FORWARDER' if count_only else 'EXPECTED_CONTRACT_NOT_OBSERVED')
    assert all(data[k] == spec[k] for k in ['domain', 'case', 'range', 'cycles', 'rounds', 'warmup'])
    runtime = Path(data['runtime_module']).resolve()
    assert sha(runtime) == plan['runtime_sha256'], 'wrong_loaded_runtime'
    assert len(data['round_records']) == spec['rounds']
    checksum, payload_bytes = oracle(spec)
    native_outputs = []
    for row in data['round_records']:
        assert row['operations'] == spec['cycles']
        assert row['checksum'] == checksum and row['payload_bytes'] == payload_bytes
        assert row['wall_ns'] > 0 and 0 <= row['hot_ns'] <= row['wall_ns']
        providers = spec['cycles'] if spec['domain'] == 'system' and spec['case'] in ('cold', 'scoped') else 1
        assert row['provider_allocations'] == row['provider_deallocations'] == providers
        if count_only:
            assert row['total_counts']['native'] == expected_native(spec, False)
            assert row['hot_counts']['native'] == expected_native(spec, True)
            for key, expected in [('provider_allocate', providers), ('provider_deallocate', providers),
                                   ('provider_retain', 1), ('provider_release', 1)]:
                assert row['total_counts'][key] == expected
            if spec['case'] in ('read', 'write'):
                assert row['hot_counts']['cpp_requests'] == 0
            c = row['config']
            assert c['struct_size'] > 0 and c['abi_major'] == 1 and c['abi_minor'] == 1
            assert c['flags'] == c['reserved'] == 0 and c['budget'] == 4096 and c['provider'] is True
            assert c['chunk'] == (4096 if spec['domain'] == 'arena' else 0)
            native_outputs.append({'total_counts': row['total_counts'], 'hot_counts': row['hot_counts'], 'config': row['config']})
    return native_outputs

def invoke(plan, executable, spec, method, count_only, directory, label):
    frozen(plan)
    argv = [executable, '--method', method]
    for key in ['case', 'domain', 'range', 'cycles', 'rounds', 'warmup']:
        argv += ['--' + key, str(spec[key])]
    env = dict(os.environ)
    variable = 'PATH' if os.name == 'nt' else 'LD_LIBRARY_PATH'
    env[variable] = plan['runtime_dir'] + os.pathsep + env.get(variable, '')
    started = datetime.now(timezone.utc).isoformat()
    stdout = directory / (label + '.stdout.json')
    stderr = directory / (label + '.stderr.txt')
    assert not stdout.exists() and not stderr.exists()
    try:
        result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=180)
    except subprocess.TimeoutExpired as error:
        stdout.write_bytes(error.stdout or b''); stderr.write_bytes(error.stderr or b'')
        save(directory / (label + '.failure.json'), {'state': 'PROCESS_TIMEOUT_NOT_RETRIED',
            'label': label, 'started_at_utc': started, 'stdout_sha256': sha(stdout),
            'stderr_sha256': sha(stderr), 'timeout_seconds': 180})
        raise
    stdout.write_bytes(result.stdout); stderr.write_bytes(result.stderr)
    entry = {'label': label, 'method': method, 'started_at_utc': started, 'exit_code': result.returncode,
        'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr), 'stdout': stdout.name, 'stderr': stderr.name}
    try:
        assert result.returncode == 0, 'native_failed:' + label
        data = json.loads(result.stdout)
        values = validate(data, spec, method, count_only, plan)
    except BaseException as error:
        save(directory / (label + '.failure.json'), entry | {'state': 'PROCESS_OR_RESULT_FAILED_NOT_RETRIED',
            'reason': type(error).__name__ + ':' + str(error)})
        raise
    frozen(plan)
    return entry, data, values

def summary(values, deltas):
    defined = [v for v in values if v is not None]
    return {'count': len(values), 'defined_ratio_count': len(defined),
        'undefined_zero_baseline_count': len(values) - len(defined),
        'median_paired_ratio': statistics.median(defined) if defined else None,
        'median_paired_delta_ns_per_op': statistics.median(deltas),
        'ratios_in_pair_order': values, 'deltas_ns_per_op_in_pair_order': deltas,
        'favorable_pairs': sum(v < 0 for v in deltas), 'unfavorable_pairs': sum(v > 0 for v in deltas),
        'equal_pairs': sum(v == 0 for v in deltas)}

def main():
    global OUT
    p = argparse.ArgumentParser(description=__doc__)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--draft', action='store_true')
    mode.add_argument('--prepare', action='store_true')
    mode.add_argument('--counts', action='store_true')
    mode.add_argument('--run', action='store_true')
    p.add_argument('--timing-exe', type=Path)
    p.add_argument('--counts-exe', type=Path)
    p.add_argument('--runtime-dir', type=Path)
    p.add_argument('--plan-sha256')
    p.add_argument('--out-dir', type=Path)
    args = p.parse_args()
    if args.out_dir:
        OUT = args.out_dir.resolve()
        assert ROOT in OUT.parents, 'output_outside_workspace'
        OUT.mkdir(parents=True, exist_ok=True)
    plan_path = OUT / 'probe-plan.private.json'
    if args.draft:
        save(OUT / 'probe-matrix.draft.json', {'state': 'DRAFT_NOT_FROZEN_NOT_BUILT_NOT_EXECUTED',
            'core_sha256': CORE, 'groups': groups(), 'timing_pairs': 8, 'timing_processes': 192,
            'count_only_processes': 24, 'performance_qualified': False})
        print('DRAFT_MATRIX_ONLY_NO_NATIVE_EXECUTION'); return
    if args.prepare:
        assert args.timing_exe and args.counts_exe and args.runtime_dir
        assert not plan_path.exists()
        runtime_name = 'mgmem.dll' if os.name == 'nt' else 'libmgmem.so'
        runtime = args.runtime_dir.resolve() / runtime_name
        prefix = args.runtime_dir.resolve().parent
        installed_headers = [prefix / 'include/mgmem/memory.hpp', prefix / 'include/mgmem/mgmem.h']
        assert sha(installed_headers[0]) == sha(ROOT / 'include/mgmem/memory.hpp')
        assert sha(installed_headers[1]) == sha(ROOT / 'include/mgmem/mgmem.h')
        package_files = sorted((prefix / 'lib/cmake/MeguvizMemory').glob('*.cmake'))
        assert len(package_files) >= 3, 'installed_cmake_package_not_observed'
        files = [ROOT / 'include/mgmem/memory.hpp', ROOT / 'src/mgmem.cpp', HERE / 'probe.cpp',
            ROOT / 'include/mgmem/mgmem.h', HERE / 'CMakeLists.txt', Path(__file__).resolve(),
            args.timing_exe.resolve(), args.counts_exe.resolve(), runtime, *installed_headers, *package_files]
        assert sha(ROOT / 'src/mgmem.cpp') == CORE, 'core_changed_this_is_header_only_round'
        plan = {'state': 'FROZEN_CPP_HEADER_EQUIVALENCE_AND_PAIRED_TIMING',
            'created_at_utc': datetime.now(timezone.utc).isoformat(), 'core_sha256': CORE,
            'header_sha256': sha(ROOT / 'include/mgmem/memory.hpp'), 'groups': groups(),
            'timing_exe': str(args.timing_exe.resolve()), 'counts_exe': str(args.counts_exe.resolve()),
            'runtime_dir': str(args.runtime_dir.resolve()), 'runtime_sha256': sha(runtime),
            'files': {str(f): {'bytes': f.stat().st_size, 'sha256': sha(f)} for f in files},
            'timing_pairs': 8, 'timing_processes': 192, 'count_only_processes': 24,
            'rules': ['No builds during timing; validate all raw results and loaded DLL identity.',
                'Same executable per raw pair; helper/manual choose before timed loop.',
                'No retries, replaced processes, exclusions or previous-round pooling.',
                'Count-only native forwarders call the real runtime; raw target has no call/allocation interception.',
                'C++ new interception covers this executable and any symbols bound to it, not all Windows DLL heap.',
                'Wall includes domain create and final RAII destroy, but not command parsing, result allocation or report.',
                'Cold means a fresh one-request domain each round, after four warmup rounds; not cold process or cold OS startup.',
                'Raw config is an expected contract label, observed effective create fields come only from native-forwarder count target.',
                'Counted C++ new events are successful upstream requests in the executable binding scope, not failed new-handler attempts or OS heap events.',
                'Persistent-owner hot holds one owner; scoped hot includes matched Arena reset.',
                'Keep all P50/P95, paired differences, undefined ratios, AB/BA and halves.'],
            'uncontrolled': ['CPU frequency', 'affinity', 'other activity', 'thread scheduling'],
            'performance_qualified': False}
        save(plan_path, plan); print(json.dumps({'plan_sha256': sha(plan_path), 'timing_processes': 192, 'count_processes': 24})); return
    assert args.plan_sha256 and sha(plan_path) == args.plan_sha256
    plan = json.loads(plan_path.read_text()); frozen(plan)
    if args.counts:
        directory = OUT / 'probe-counts'; directory.mkdir(exist_ok=False)
        receipt = {'state': 'RUNNING', 'plan_sha256': sha(plan_path), 'processes': [], 'groups': [], 'performance_qualified': False}
        try:
            for group in plan['groups']:
                spec = dict(group, cycles=1 if group['case'] == 'cold' else 8, rounds=2, warmup=0)
                values = {}
                for method in ['manual', 'helper']:
                    entry, data, native = invoke(plan, plan['counts_exe'], spec, method, True, directory, group['id'] + '-' + method)
                    receipt['processes'].append(entry); values[method] = native
                assert values['manual'] == values['helper'], 'extra_calls_or_cpp_allocations:' + group['id']
                receipt['groups'].append({'id': group['id'], 'state': 'PASS_EXACT_CALL_AND_ALLOCATION_EQUIVALENCE', 'round_records': values['manual']})
            assert len(receipt['processes']) == 24
            receipt['state'] = 'PASS_24_REAL_CORE_COUNT_EQUIVALENCE_PROCESSES'
        except BaseException as e:
            receipt.update(state='FAILED_COUNT_EQUIVALENCE', reason=type(e).__name__ + ':' + str(e)); raise
        finally:
            save(OUT / 'probe-count-receipt.private.json', receipt)
        print(receipt['state']); return
    counts = json.loads((OUT / 'probe-count-receipt.private.json').read_text())
    assert counts['state'] == 'PASS_24_REAL_CORE_COUNT_EQUIVALENCE_PROCESSES'
    directory = OUT / 'probe-timing'; directory.mkdir(exist_ok=False)
    receipt = {'state': 'RUNNING', 'plan_sha256': sha(plan_path),
        'count_receipt_sha256': sha(OUT / 'probe-count-receipt.private.json'), 'processes': [], 'groups': [], 'performance_qualified': False}
    try:
        for spec in plan['groups']:
            pairs = []
            for pair in range(plan['timing_pairs']):
                ordered = ['manual', 'helper'] if pair % 2 == 0 else ['helper', 'manual']
                results = {}
                for method in ordered:
                    label = spec['id'] + '-p' + str(pair) + '-' + method
                    entry, data, _ = invoke(plan, plan['timing_exe'], spec, method, False, directory, label)
                    receipt['processes'].append(entry); results[method] = data
                pair_row = {'pair': pair, 'order': ordered, 'metrics': {}}
                for metric in ['hot_ns', 'wall_ns']:
                    for pct, fraction in [('p50', .5), ('p95', .95)]:
                        a = percentile([r[metric] / spec['cycles'] for r in results['manual']['round_records']], fraction)
                        b = percentile([r[metric] / spec['cycles'] for r in results['helper']['round_records']], fraction)
                        pair_row['metrics'][metric + '_' + pct] = {'manual': a, 'helper': b, 'ratio': b / a if a else None, 'delta': b - a}
                pairs.append(pair_row)
            group = {'id': spec['id'], 'configuration': spec, 'pairs': pairs, 'metrics': {}}
            for key in pairs[0]['metrics']:
                ratios = [p['metrics'][key]['ratio'] for p in pairs]
                deltas = [p['metrics'][key]['delta'] for p in pairs]
                value = summary(ratios, deltas)
                value['first_half'] = summary(ratios[:4], deltas[:4])
                value['last_half'] = summary(ratios[4:], deltas[4:])
                value['ab'] = summary(ratios[::2], deltas[::2])
                value['ba'] = summary(ratios[1::2], deltas[1::2])
                group['metrics'][key] = value
            receipt['groups'].append(group)
        assert len(receipt['processes']) == 192 and len(receipt['groups']) == 12
        receipt['state'] = 'PASS_192_PAIRED_CPP_CONVENIENCE_PROCESSES_ALL_RETAINED'
    except BaseException as e:
        receipt.update(state='FAILED_PAIRED_CPP_CONVENIENCE', reason=type(e).__name__ + ':' + str(e)); raise
    finally:
        save(OUT / 'probe-performance.private.json', receipt)
    print(receipt['state'])

if __name__ == '__main__':
    main()
