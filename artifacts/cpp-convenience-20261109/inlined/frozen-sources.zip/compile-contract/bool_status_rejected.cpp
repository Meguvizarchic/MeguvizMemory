#include <mgmem/memory.hpp>
void rejected(mgmem::owned_allocation &owner) {
 (void)owner.with_write([](void *, uint64_t) { return true; });
}
