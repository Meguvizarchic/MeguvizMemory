#include <mgmem/memory.hpp>
void accepted(mgmem::owned_allocation &owner) {
 (void)owner.with_read([](const void *, uint64_t) {});
 (void)owner.with_write([](void *, uint64_t) -> mgmem_status { return MGMEM_OK; });
}
