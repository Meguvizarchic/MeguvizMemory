#include <mgmem/memory.hpp>
void rejected(mgmem::owned_allocation &owner) {
 (void)owner.with_read([](void *, uint64_t) {});
}
