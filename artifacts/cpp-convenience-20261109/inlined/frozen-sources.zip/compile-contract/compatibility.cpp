#include <mgmem/memory.hpp>

#ifdef MGMEM_CPP_BORROW_INLINE
#error The implementation inline macro escaped the header
#endif

namespace compatibility {
using ReadCallback = mgmem_status (*)(const void *, uint64_t);
using BorrowMember = mgmem_status (mgmem::owned_allocation::*)(uint64_t, uint64_t,
    uint32_t, mgmem::borrow &) const noexcept;
BorrowMember acquire_member = &mgmem::owned_allocation::acquire_borrow;

struct RecursiveRead {
    mgmem::owned_allocation &owner;
    unsigned remaining;
    mgmem_status operator()(const void *, uint64_t) const {
        if (!remaining) return MGMEM_OK;
        return owner.with_read(RecursiveRead{owner, remaining - 1});
    }
};

void recursive_two_reads(mgmem::owned_allocation &owner) {
    (void)owner.with_read(RecursiveRead{owner, 2});
}

void body_with_try_catch(mgmem::owned_allocation &owner) {
    (void)owner.with_read([](const void *, uint64_t bytes) -> mgmem_status {
        try {
            if (bytes == 17) throw 7;
            return MGMEM_OK;
        } catch (int) {
            return MGMEM_BUSY;
        }
    });
}

void caller_with_try_catch(mgmem::owned_allocation &owner) {
    try {
        (void)owner.with_write([](void *, uint64_t bytes) {
            if (bytes == 19) throw 9;
        });
    } catch (int) {
    }
}

mgmem_status read_function(const void *, uint64_t) { return MGMEM_OK; }

void function_pointer(mgmem::owned_allocation &owner, ReadCallback callback) {
    (void)owner.with_read(callback);
    (void)owner.with_read(&read_function);
}

void member_pointer(mgmem::owned_allocation &owner, BorrowMember member,
                    mgmem::borrow &view) {
    (void)(owner.*member)(0, 1, MGMEM_READ, view);
    (void)(owner.*acquire_member)(0, 1, MGMEM_READ, view);
}
} // namespace compatibility
