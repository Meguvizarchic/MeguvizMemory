#ifndef MGMEM_HEAP_PROBE_ARRAY_TRACKING_HPP
#define MGMEM_HEAP_PROBE_ARRAY_TRACKING_HPP

#include "counting_allocator.hpp"
#include <array>
#include <cstdlib>
#include <mutex>

namespace heap_probe {
struct ArrayEntry { void *address = nullptr; std::size_t bytes = 0; bool table = false; };
inline std::array<ArrayEntry, 64> array_registry{};
inline std::mutex array_mutex;
inline thread_local unsigned table_array_depth = 0;
inline uint64_t marked_array_allocations = 0, marked_array_deallocations = 0;
inline uint64_t unmarked_array_allocations = 0, unmarked_array_deallocations = 0;
inline uint64_t peak_registered_arrays = 0, peak_marked_arrays = 0, registry_errors = 0;

struct TableArrayScope {
    TableArrayScope() noexcept { ++table_array_depth; }
    ~TableArrayScope() { --table_array_depth; }
    TableArrayScope(const TableArrayScope &) = delete;
    TableArrayScope &operator=(const TableArrayScope &) = delete;
};

inline void *allocate_array(std::size_t bytes) {
    const bool marked = table_array_depth != 0;
    if (marked) counters[MGMEM_HP_LEASE_TABLE_STORAGE].attempts.fetch_add(1, std::memory_order_relaxed);
    void *address;
    try { address = ::operator new(bytes); }
    catch (...) {
        if (marked) counters[MGMEM_HP_LEASE_TABLE_STORAGE].failed.fetch_add(1, std::memory_order_relaxed);
        throw;
    }
    std::lock_guard<std::mutex> lock(array_mutex);
    ArrayEntry *empty = nullptr;
    size_t live = 0, marked_live = 0;
    for (auto &entry : array_registry) {
        if (entry.address) { ++live; if (entry.table) ++marked_live; }
        else if (!empty) empty = &entry;
    }
    if (!empty) {
        ++registry_errors;
        ::operator delete(address);
        if (marked) counters[MGMEM_HP_LEASE_TABLE_STORAGE].failed.fetch_add(1, std::memory_order_relaxed);
        throw std::bad_alloc();
    }
    *empty = {address, bytes, marked};
    if (live + 1 > peak_registered_arrays) peak_registered_arrays = live + 1;
    if (marked) {
        if (marked_live + 1 > peak_marked_arrays) peak_marked_arrays = marked_live + 1;
        ++marked_array_allocations;
        record_allocation(MGMEM_HP_LEASE_TABLE_STORAGE, static_cast<uint64_t>(bytes));
    } else ++unmarked_array_allocations;
    return address;
}

inline void deallocate_array(void *address) noexcept {
    if (!address) return;
    std::lock_guard<std::mutex> lock(array_mutex);
    for (auto &entry : array_registry) if (entry.address == address) {
        // Every array handled here was allocated by allocate_array via scalar
        // global new. Use its matching scalar delete, with no cookie/header.
        ::operator delete(address);
        if (entry.table) {
            ++marked_array_deallocations;
            record_deallocation(MGMEM_HP_LEASE_TABLE_STORAGE, static_cast<uint64_t>(entry.bytes));
        } else ++unmarked_array_deallocations;
        entry = {};
        return;
    }
    ++registry_errors;
    std::abort(); // Unknown ownership is a failed diagnostic, never a fallback.
}

inline bool array_snapshot(mgmem_heap_probe_array_v1 &out) noexcept {
    std::lock_guard<std::mutex> lock(array_mutex);
    uint64_t marked = 0, unmarked = 0;
    for (const auto &entry : array_registry) if (entry.address) {
        if (entry.table) ++marked;
        else ++unmarked;
    }
    out = {marked_array_allocations, marked_array_deallocations,
        unmarked_array_allocations, unmarked_array_deallocations, marked,
        unmarked, peak_registered_arrays, peak_marked_arrays, array_registry.size(), registry_errors};
    return registry_errors == 0;
}
} // namespace heap_probe

// Diagnostic TU replacements only. The actual new[] byte argument is observed;
// the registry does not prepend any bytes or alter the returned address.
void *operator new[](std::size_t bytes) { return heap_probe::allocate_array(bytes); }
void operator delete[](void *address) noexcept { heap_probe::deallocate_array(address); }
void operator delete[](void *address, std::size_t) noexcept { heap_probe::deallocate_array(address); }

#endif
