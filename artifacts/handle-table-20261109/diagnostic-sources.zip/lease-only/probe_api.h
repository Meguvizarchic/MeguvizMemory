#ifndef MGMEM_HEAP_PROBE_API_H
#define MGMEM_HEAP_PROBE_API_H

#include <stdint.h>

#if defined(_WIN32)
# if defined(MGMEM_HEAP_PROBE_BUILDING)
#  define MGMEM_HEAP_PROBE_API __declspec(dllexport)
# else
#  define MGMEM_HEAP_PROBE_API __declspec(dllimport)
# endif
#else
# define MGMEM_HEAP_PROBE_API __attribute__((visibility("default")))
#endif

enum {
    MGMEM_HP_DOMAIN = 0,
    MGMEM_HP_ALLOCATION_MAP = 1,
    MGMEM_HP_LEASE_TABLE_STORAGE = 2,
    MGMEM_HP_BACKING_LIST = 3,
    MGMEM_HP_RANGE_CLAIM_LIST = 4,
    MGMEM_HP_KIND_COUNT = 5
};

typedef struct mgmem_heap_probe_counter_v1 {
    uint64_t allocation_attempts;
    uint64_t successful_allocations;
    uint64_t failed_allocations;
    uint64_t deallocations;
    uint64_t allocated_request_bytes;
    uint64_t deallocated_request_bytes;
    uint64_t live_request_bytes;
    uint64_t peak_live_request_bytes;
    uint64_t smallest_request_bytes;
    uint64_t largest_request_bytes;
} mgmem_heap_probe_counter_v1;

typedef struct mgmem_heap_probe_array_v1 {
    uint64_t marked_allocations, marked_deallocations;
    uint64_t unmarked_allocations, unmarked_deallocations;
    uint64_t live_marked_arrays, live_unmarked_arrays;
    uint64_t peak_registered_arrays, peak_live_marked_arrays;
    uint64_t registry_capacity, registry_errors;
} mgmem_heap_probe_array_v1;

#ifdef __cplusplus
extern "C" {
#endif

/* Build-only diagnostic symbol, never added to the production header or SDK.
 * Read only at quiescent points. This is not a transactional concurrent view. */
MGMEM_HEAP_PROBE_API uint32_t mgmem_heap_probe_snapshot_v1(
    mgmem_heap_probe_counter_v1 *out, uint32_t count);
MGMEM_HEAP_PROBE_API uint32_t mgmem_heap_probe_array_snapshot_v1(mgmem_heap_probe_array_v1 *out);

#ifdef __cplusplus
}
#endif
#endif
