#define PROBE_LAYOUT_FLAT 1
#define PROBE_LAYOUT_COUNTED 1
#include "core.counted.cpp"

#include <cstdio>
#include <type_traits>
#include <utility>
int main() {
    using Storage = decltype(std::declval<mgmem_domain>().leases);
    std::printf("{\"scope\":\"HOST_RELEASE_CONTROL_LAYOUT_ONLY_NOT_RSS\",\"instrumented\":%s,\"storage\":\"%s\",\"domain\":%llu,\"allocation_map\":%llu,\"lease_storage_object\":%llu,\"Lease\":%llu,\"Allocation\":%llu,\"Backing\":%llu,\"pointer\":%llu",
        PROBE_LAYOUT_COUNTED ? "true" : "false", PROBE_LAYOUT_FLAT ? "SBO1_FLAT_ARRAY" : "STD_MAP_NODES",
        (unsigned long long)sizeof(mgmem_domain), (unsigned long long)sizeof(std::declval<mgmem_domain>().allocations),
        (unsigned long long)sizeof(Storage), (unsigned long long)sizeof(Lease), (unsigned long long)sizeof(Allocation),
        (unsigned long long)sizeof(Backing), (unsigned long long)sizeof(void *));
#if PROBE_LAYOUT_FLAT
    std::printf(",\"flat_slot\":%llu", (unsigned long long)sizeof(*std::declval<Storage &>().find(1)));
#endif
    std::printf("}\n");
}
