#include <mgmem/mgmem.h>
#include "probe_api.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#if defined(_WIN32)
#define NOMINMAX
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace {
using u64 = uint64_t;
using Counters = std::array<mgmem_heap_probe_counter_v1, MGMEM_HP_KIND_COUNT>;
constexpr const char *kind_names[] = {"domain", "allocation_map", "lease_table_storage", "backing_list", "range_claim_list"};
struct Observation { std::string stage; Counters counters; mgmem_heap_probe_array_v1 arrays{}; };
struct Options {
    std::string shape = "fixed", profile = "prepared-single", mode = "stream", cleanup = "collect";
    u64 allocations = 32, batch = 32, rounds = 2;
};
void check(mgmem_status status, const char *operation) {
    if (status != MGMEM_OK) throw std::runtime_error(std::string(operation) + "_status_" + std::to_string(status));
}
u64 number(const std::string &value) {
    if (value.empty() || value.size() > 8 || value.find_first_not_of("0123456789") != std::string::npos)
        throw std::runtime_error("invalid_unsigned_number");
    return std::stoull(value);
}
std::string quote(const std::string &value) {
    std::string result = "\"";
    const char *hex = "0123456789abcdef";
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') { result += '\\'; result += static_cast<char>(c); }
        else if (c < 32) { result += "\\u00"; result += hex[c >> 4]; result += hex[c & 15]; }
        else result += static_cast<char>(c);
    }
    return result + '"';
}
std::string module_path() {
#if defined(_WIN32)
    HMODULE module = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&mgmem_allocate_v1), &module))
        throw std::runtime_error("runtime_module_not_observed");
    std::vector<wchar_t> path(32768);
    const DWORD length = GetModuleFileNameW(module, path.data(), static_cast<DWORD>(path.size()));
    if (!length || length >= path.size()) throw std::runtime_error("runtime_module_path_invalid");
    const int count = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, path.data(),
        static_cast<int>(length), nullptr, 0, nullptr, nullptr);
    if (count <= 0) throw std::runtime_error("runtime_module_path_encoding");
    std::string result(static_cast<size_t>(count), '\0');
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, path.data(), static_cast<int>(length),
            result.data(), count, nullptr, nullptr) != count)
        throw std::runtime_error("runtime_module_path_encoding");
    return result;
#else
    Dl_info info{};
    if (!dladdr(reinterpret_cast<void *>(&mgmem_allocate_v1), &info) || !info.dli_fname)
        throw std::runtime_error("runtime_module_not_observed");
    return info.dli_fname;
#endif
}
Counters counters() {
    Counters result{};
    if (mgmem_heap_probe_snapshot_v1(result.data(), static_cast<uint32_t>(result.size())) != 1)
        throw std::runtime_error("probe_snapshot_rejected");
    return result;
}
mgmem_heap_probe_array_v1 array_counters() {
    mgmem_heap_probe_array_v1 result{};
    if (mgmem_heap_probe_array_snapshot_v1(&result) != 1) throw std::runtime_error("array_registry_invalid");
    return result;
}
void print_arrays(const mgmem_heap_probe_array_v1 &v) {
    std::cout << "{\"marked_allocations\":" << v.marked_allocations
        << ",\"marked_deallocations\":" << v.marked_deallocations
        << ",\"unmarked_allocations\":" << v.unmarked_allocations
        << ",\"unmarked_deallocations\":" << v.unmarked_deallocations
        << ",\"live_marked_arrays\":" << v.live_marked_arrays
        << ",\"live_unmarked_arrays\":" << v.live_unmarked_arrays
        << ",\"peak_registered_arrays\":" << v.peak_registered_arrays
        << ",\"peak_live_marked_arrays\":" << v.peak_live_marked_arrays
        << ",\"registry_capacity\":" << v.registry_capacity
        << ",\"registry_errors\":" << v.registry_errors << '}';
}
mgmem_snapshot_v1 snapshot(mgmem_domain *domain) {
    mgmem_snapshot_v1 result{};
    check(mgmem_domain_snapshot_v1(domain, &result, sizeof(result)), "snapshot");
    return result;
}
u64 size_for(const Options &options, u64 operation) {
    return options.shape == "mixed" ? (operation % 4 + 1) * 32 : 64;
}
u64 alignment_for(const Options &options, u64 operation) {
    return options.shape == "mixed" ? u64{8} << (operation % 4) : 16;
}
u64 expected_checksum(const Options &options) {
    u64 result = 0;
    for (u64 operation = 0; operation < options.allocations; ++operation)
        for (u64 byte = 0; byte < size_for(options, operation); ++byte)
            result += (operation * 31 + byte) & 255;
    return result * options.rounds;
}
void require_idle(const mgmem_snapshot_v1 &value) {
    if (value.active_allocations || value.active_leases || value.live_bytes || value.retiring_bytes || value.reserved_bytes)
        throw std::runtime_error("owners_leases_or_reservations_nonzero");
}
void print_counter(const mgmem_heap_probe_counter_v1 &c) {
    std::cout << "{\"allocation_attempts\":" << c.allocation_attempts
        << ",\"successful_allocations\":" << c.successful_allocations
        << ",\"failed_allocations\":" << c.failed_allocations
        << ",\"deallocations\":" << c.deallocations
        << ",\"allocated_request_bytes\":" << c.allocated_request_bytes
        << ",\"deallocated_request_bytes\":" << c.deallocated_request_bytes
        << ",\"live_request_bytes\":" << c.live_request_bytes
        << ",\"peak_live_request_bytes\":" << c.peak_live_request_bytes
        << ",\"smallest_request_bytes\":" << c.smallest_request_bytes
        << ",\"largest_request_bytes\":" << c.largest_request_bytes << '}';
}
} // namespace

int main(int argc, char **argv) {
    try {
        Options options;
        for (int i = 1; i < argc; i += 2) {
            if (i + 1 >= argc) throw std::runtime_error("missing_option_value");
            const std::string key = argv[i], value = argv[i + 1];
            if (key == "--shape") options.shape = value;
            else if (key == "--profile") options.profile = value;
            else if (key == "--mode") options.mode = value;
            else if (key == "--cleanup") options.cleanup = value;
            else if (key == "--allocations") options.allocations = number(value);
            else if (key == "--batch") options.batch = number(value);
            else if (key == "--rounds") options.rounds = number(value);
            else throw std::runtime_error("unknown_option");
        }
        if ((options.shape != "fixed" && options.shape != "mixed") ||
                (options.profile != "default" && options.profile != "prepared-single") ||
                (options.mode != "stream" && options.mode != "held") ||
                (options.cleanup != "collect" && options.cleanup != "trim-collect") ||
                options.allocations < 1 || options.allocations > 65536 ||
                options.batch < 1 || options.batch > 256 || options.batch > options.allocations ||
                options.rounds < 1 || options.rounds > 64)
            throw std::runtime_error("workload_out_of_bounds");
        const bool single = options.profile == "prepared-single";
        if (single && (options.allocations != 32 || options.batch != 32))
            throw std::runtime_error("prepared_single_requires_32_requests_batch32");

        const std::string module = module_path();
        std::vector<Observation> observations;
        observations.reserve(static_cast<size_t>(options.rounds * 2 + 6));
        const auto record = [&](const std::string &stage) { observations.push_back({stage, counters(), array_counters()}); };
        record("startup_before_domain");
        mgmem_domain_options_v1 config{sizeof(config), MGMEM_ABI_MAJOR, MGMEM_ABI_MINOR,
            0, MGMEM_ARENA, 0, single ? 4096 : options.allocations * 512 + 4096, 4096, nullptr};
        mgmem_domain *domain = nullptr;
        check(mgmem_domain_create_v1(&config, &domain), "create");
        record("after_domain_create");
        if (single) {
            mgmem_handle_v1 owner{};
            check(mgmem_allocate_v1(domain, 4096, 64, &owner), "prepare");
            check(mgmem_release_v1(domain, owner), "prepare_release");
            check(mgmem_arena_reset_v1(domain), "prepare_reset");
            const auto ready = snapshot(domain);
            require_idle(ready);
            if (ready.provider_allocation_count != 1 || ready.backing_bytes != 4096 || ready.peak_backing_bytes != 4096)
                throw std::runtime_error("single_preparation_capacity_mismatch");
        }
        record("after_prepare_before_work");

        std::vector<mgmem_handle_v1> owners(static_cast<size_t>(options.batch));
        std::vector<mgmem_borrow_v1> held(static_cast<size_t>(options.batch));
        u64 checksum = 0;
        for (u64 round = 0; round < options.rounds; ++round) {
            for (u64 first = 0; first < options.allocations; first += options.batch) {
                const u64 count = std::min(options.batch, options.allocations - first);
                for (u64 i = 0; i < count; ++i)
                    check(mgmem_allocate_v1(domain, size_for(options, first + i), alignment_for(options, first + i),
                        &owners[static_cast<size_t>(i)]), "allocate");
                for (u64 i = 0; i < count; ++i) {
                    const auto operation = first + i;
                    const auto size = size_for(options, operation);
                    mgmem_borrow_v1 view{};
                    check(mgmem_borrow_acquire_v1(domain, owners[static_cast<size_t>(i)], 0, size, MGMEM_WRITE, &view), "borrow");
                    auto *bytes = static_cast<volatile unsigned char *>(view.data);
                    if (reinterpret_cast<uintptr_t>(bytes) % alignment_for(options, operation))
                        throw std::runtime_error("alignment_mismatch");
                    for (u64 byte = 0; byte < size; ++byte) bytes[byte] = static_cast<unsigned char>(operation * 31 + byte);
                    for (u64 byte = 0; byte < size; ++byte) {
                        if (bytes[byte] != static_cast<unsigned char>(operation * 31 + byte))
                            throw std::runtime_error("payload_mismatch");
                        checksum += bytes[byte];
                    }
                    if (options.mode == "held") held[static_cast<size_t>(i)] = view;
                    else {
                        check(mgmem_release_v1(domain, owners[static_cast<size_t>(i)]), "release_owner_while_lease_live");
                        check(mgmem_borrow_release_v1(domain, view.lease), "release_lease");
                    }
                }
                if (options.mode == "held") {
                    for (u64 i = 0; i < count; ++i)
                        check(mgmem_release_v1(domain, owners[static_cast<size_t>(i)]), "held_release_owner");
                    for (u64 i = 0; i < count; ++i)
                        check(mgmem_borrow_release_v1(domain, held[static_cast<size_t>(i)].lease), "held_release_lease");
                }
            }
            const auto state = snapshot(domain);
            require_idle(state);
            if (single && (state.provider_allocation_count != 1 || state.peak_backing_bytes != 4096))
                throw std::runtime_error("provider_published_in_single_work");
            record("round_" + std::to_string(round) + "_after_work");
            check(mgmem_arena_reset_v1(domain), "round_reset");
            record("round_" + std::to_string(round) + "_after_reset");
        }
        if (checksum != expected_checksum(options)) throw std::runtime_error("checksum_oracle_mismatch");
        const auto before_close = snapshot(domain);
        record("before_close");
        if (options.cleanup == "trim-collect") {
            record("before_trim");
            check(mgmem_domain_trim_v1(domain), "trim");
            const auto trimmed = snapshot(domain);
            require_idle(trimmed);
            if (trimmed.backing_bytes != 0) throw std::runtime_error("trim_backing_nonzero");
            record("after_trim");
            if (observations.back().counters[MGMEM_HP_LEASE_TABLE_STORAGE].live_request_bytes !=
                    observations[1].counters[MGMEM_HP_LEASE_TABLE_STORAGE].live_request_bytes)
                throw std::runtime_error("trim_retained_lease_storage");
        }
        check(mgmem_domain_begin_close_v1(domain), "begin_close");
        check(mgmem_domain_collect_v1(domain), "collect");
        check(mgmem_domain_drain_v1(domain, 0), "drain");
        const auto closed = snapshot(domain);
        require_idle(closed);
        if (closed.state != MGMEM_CLOSED || closed.backing_bytes != 0)
            throw std::runtime_error("domain_not_closed_zero");
        record("after_close_before_destroy");
        if (observations.back().counters[MGMEM_HP_LEASE_TABLE_STORAGE].live_request_bytes !=
                observations[1].counters[MGMEM_HP_LEASE_TABLE_STORAGE].live_request_bytes)
            throw std::runtime_error("collect_retained_lease_storage");
        check(mgmem_domain_destroy_v1(domain), "destroy");
        record("after_domain_destroy");
        const auto &initial_arrays = observations.front().arrays;
        const auto &final_arrays = observations.back().arrays;
        if (final_arrays.registry_errors || final_arrays.live_marked_arrays != initial_arrays.live_marked_arrays ||
                final_arrays.live_unmarked_arrays != initial_arrays.live_unmarked_arrays ||
                final_arrays.peak_live_marked_arrays > 2)
            throw std::runtime_error("array_registry_lifetime_mismatch");
        const auto &startup = observations.front().counters;
        const auto &final = observations.back().counters;
        for (unsigned kind = 0; kind < MGMEM_HP_KIND_COUNT; ++kind) {
            if (final[kind].live_request_bytes != startup[kind].live_request_bytes ||
                    final[kind].allocated_request_bytes - final[kind].deallocated_request_bytes != final[kind].live_request_bytes ||
                    final[kind].successful_allocations - final[kind].deallocations !=
                        startup[kind].successful_allocations - startup[kind].deallocations ||
                    final[kind].failed_allocations)
                throw std::runtime_error("metadata_did_not_return_to_startup_baseline");
        }

        std::cout << "{\"schema_version\":1,\"workload\":\"lease_table_metadata_heap_count_v1\",\"success\":true,"
            << "\"scope\":\"COUNT_ONLY_INSTRUMENTED_CORE_NOT_TIMING_OR_PERFORMANCE\",\"runtime_module\":" << quote(module)
            << ",\"profile\":" << quote(options.profile) << ",\"shape\":" << quote(options.shape)
            << ",\"mode\":" << quote(options.mode) << ",\"cleanup\":" << quote(options.cleanup)
            << ",\"probe_variant\":" << quote(MGMEM_HEAP_PROBE_VARIANT)
            << ",\"lease_storage_representation\":" << quote(MGMEM_HEAP_PROBE_STORAGE)
            << ",\"unmodified_core_source_sha256\":" << quote(MGMEM_HEAP_PROBE_SOURCE_SHA)
            << ",\"threads\":1,\"allocations_per_round\":" << options.allocations << ",\"batch\":" << options.batch
            << ",\"rounds\":" << options.rounds << ",\"completed_operations\":" << options.allocations * options.rounds
            << ",\"checksum\":" << checksum << ",\"expected_checksum\":" << expected_checksum(options)
            << ",\"provider_publications_before_close\":" << before_close.provider_allocation_count
            << ",\"peak_backing_bytes\":" << before_close.peak_backing_bytes
            << ",\"core_resources\":\"CLOSED_ZERO\",\"metadata_resources\":\"RETURNED_TO_STARTUP_BASELINE\","
            << "\"instrumentation_upstream\":\"STD_ALLOCATOR_REBIND_AND_SCOPED_ACTUAL_ARRAY_OPERATOR_BYTES\","
            << "\"performance_qualified\":false,\"observations\":[";
        for (size_t i = 0; i < observations.size(); ++i) {
            if (i) std::cout << ',';
            std::cout << "{\"stage\":" << quote(observations[i].stage) << ",\"counters\":{";
            for (unsigned kind = 0; kind < MGMEM_HP_KIND_COUNT; ++kind) {
                if (kind) std::cout << ',';
                std::cout << quote(kind_names[kind]) << ':';
                print_counter(observations[i].counters[kind]);
            }
            std::cout << "},\"array_tracking\":"; print_arrays(observations[i].arrays); std::cout << "}";
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << "heap_probe_failed:" << error.what() << '\n';
        return 1;
    }
}
